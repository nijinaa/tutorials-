from django.shortcuts import render
from django.shortcuts import render, redirect
from .forms import SignUpForm, LoginForm,CustomerForm
from django.contrib.auth import authenticate, login
import email
from pyexpat.errors import messages
from django.shortcuts import render,HttpResponse,redirect
from .models import vaccinationhistory,vaccine,register
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# Create your views here.


def index(request):
    return render(request, 'index.html')


def registerall(request):
    msg = None
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            msg = 'user created'
            return redirect('login_view')
        else:
            msg = 'form is not valid'
    else:
        form = SignUpForm()
    return render(request,'register.html', {'form': form, 'msg': msg})


def login_view(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)

            if user is not None and user.is_staff:
                login(request, user)
                return redirect('staff')
            elif user is not None and user.is_user:
                login(request, user)
                return redirect('user')
            else:
                msg= 'invalid credentials'
        else:
            msg = 'error validating form'
    return render(request, 'login.html', {'form': form, 'msg': msg})

def logout_view(request):
    logout(request)
    return redirect('index')
def Resethome(request):
    return render(request,'Resetpassword.html')
def resetPassword(request):
   
    try:
        username=request.POST['uname']
        newpwd=request.POST['password']
      
        user=User.objects.get(username=username)
        if user is not None:
            user.set_password(newpwd)
            user.save()
            #send_mail(subject,message,EMAIL_HOST_USER,[recepient])
            msg="Password Reset Successfully"
            return render (request,"Resetpassword.html",{'msg':msg})

        
    except Exception as e:
        print(e)
        msg="Failed to reset password"
        return render(request,"Resetpassword.html",{'msg':msg})

def staff(request):
    return render(request,'staff.html')


def user(request):
    return render(request,'user.html')



def registeruser(request):
    custform=CustomerForm()
    return render(request,"registeruser.html",{"form":custform})

def uservaccine(request):
    try:
        if request.method=="POST":
            custform=CustomerForm(request.POST)
            if custform.is_valid():
                custform.save()
                #return redirect ('home')
        return render(request,'registeruser.html',{'form':custform,"msg":"Registration successfull"})
    except Exception as e:
        print(e)
        return HttpResponse("Error")
def history(request):
    his=vaccinationhistory.objects.all()
    context = {
        'his':his
    }
    return render(request,'history.html',context)
def addvaccination(request):
    if request.method=='POST':
        date=request.POST['date']
        name=request.POST['name']
        vinfo=request.POST['vinfo']
        status=request.POST['status']
        adhar_no=request.POST['adhar']
        created_by=request.POST['created']
        p=vaccinationhistory(date=date,name=name,adhar_no=adhar_no,created_by=created_by,vaccination_info=vinfo,status=status)
        p.save()
        return render(request,'addvaccination.html',{"msg":"Vaccination details added successfully"})
        #return HttpResponse('VACCINATION DETAILS  ADDED SUCCESSFULLY')
    else:
       
        return render(request,'addvaccination.html')


def vaccinelist(request):
    his=vaccine.objects.all()
    context = {
        'his':his
    }
    return render(request,'list.html',context)
def uservaccinelist(request):
    his=vaccine.objects.all()
    context = {
        'his':his
    }
    return render(request,'uservaccinelistpage.html',context)
def userlist(request):
    his=register.objects.all()
    context = {
        'his':his
    }
    return render(request,'userlist.html',context)
   

def addvaccines(request):
    
    if request.method=='POST':
        center=request.POST['center']
        vname=request.POST['vname']
        status=request.POST['status']
        p=vaccine(vaccination_center=center,vaccine_name=vname,status=status)
        p.save()
        return render(request,'add.html',{"msg":"Vaccine added successfully"})
        #return HttpResponse('VACCINE ADDED SUCCESSFULLY')
    else:
     return render(request,'add.html')
def adduser(request):
    
    if request.method=='POST':
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email']
        phone=request.POST['phone']
        role=request.POST['role']
        p=register(firstname=fname,lastname=lname,email=email,phone=phone,role=role)
        p.save()
        return render(request,'adduser.html',{"msg":"User added successfully"})
        #return HttpResponse('USER ADDED SUCCESSFULLY')
    else:
     return render(request,'adduser.html')


def deletevaccines(request,pk):

    obj=vaccine.objects.get(id=pk)
    obj.delete()
    return render(request,'list.html',{"msg":"Vaccine details deleted"})
    #return HttpResponse('VACCINE DELETED SUCCESSFULLY')
   
   
def deletehis(request,pk):

    obj=vaccinationhistory.objects.get(id=pk)
    obj.delete()
    return HttpResponse('VACCINE DELETED SUCCESSFULLY')


def updatehistory(request):
  
    if request.method=='POST':
        adhar_no=int(request.POST['adhar'])
        date=request.POST['date']
        vinfo=request.POST['vinfo']
        status=request.POST['status']
        vac=vaccinationhistory.objects.filter(adhar_no=adhar_no)
        if vac.exists():
            vac.update(date=date,vaccination_info=vinfo,status=status)
        return render(request,'updatevac.html',{"msg":"Vaccination history updated successfully"})
        #return HttpResponse('VACCINE UPDATED SUCCESSFULLY')
    else:
     return render(request,'updatevac.html')

def updatevaccine(request):
  
    if request.method=='POST':
        center=request.POST['center']
        vname=request.POST['vname']
        status=request.POST['status']
        vac=vaccine.objects.filter(vaccination_center=center)
        if vac.exists():
            vac.update(vaccine_name=vname,status=status)
            return render(request,'updatevaccine.html',{"msg":"Vaccines updated successfully"})
            #return HttpResponse('VACCINE UPDATED SUCCESSFULLY')
        else:
             return HttpResponse('PLEASE ENTER CORRECT DETAILS FOR UPDATION')
    else:
     return render(request,'updatevaccine.html')

def slot(request):
    if request.method=='POST':
        phone=int(request.POST['phone'])
        name=request.POST['name']
        slot=request.POST['slot']
      
        vac=register.objects.filter(phone=phone,firstname=name)
        if vac.exists():
            vac.update(slot=slot)
        return render(request,'slotbook.html',{"msg":"slot booked successfully"})
        #return HttpResponse('SLOT BOOKED SUCCESSFULLY')
    else:
     return render(request,'slotbook.html')
