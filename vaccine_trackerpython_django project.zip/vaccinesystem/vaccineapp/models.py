from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class User(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_user = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)


class vaccinationhistory(models.Model):
    date = models.DateField()
    name=models.CharField(max_length=10,blank=False)
    vaccination_info=models.CharField(max_length=30)
    status=models.CharField(max_length=20)
    ph_no=models.BigIntegerField(default=False)
    adhar_no=models.BigIntegerField(default=False)
    created_by=models.CharField(max_length=30,default=False)
    def __str__(self):
	    return self.name


class vaccine(models.Model):
    vaccination_center=models.CharField(max_length=30,blank=False)
    vaccine_name=models.CharField(max_length=30,blank=False)
    status = models.CharField(max_length=30)
    def __str__(self):
	    return self.vaccine_name




class register(models.Model):
    firstname=models.CharField(max_length=20,blank=False)
    lastname=models.CharField(max_length=20)
    email=models.CharField(max_length=30)
    phone = models.BigIntegerField()
    slot=models.DateField()

    def __str__(self):
	    return self.firstname


