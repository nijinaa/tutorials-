from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name= 'index'),
    path('login/', views.login_view, name='login_view'),
    path('register/', views.registerall, name='register'),
    path('logout',views.logout_view),
    path('reset',views.Resethome,name='reset'),
    path('passwordreset',views.resetPassword,name='resetpassword'),
    #path('adminpage/', views.admin, name='adminpage'),
    path('staff/', views.staff, name='staff'),
    path('user/', views.user, name='user'),
    path('slotbook',views.slot,name='slotbook'),
    path('registeruser',views.registeruser),
    path('uservaccine',views.uservaccine),
    path('index',views.index, name='index'),
    path('his',views.history, name='history'),
    path('addvac',views.addvaccination, name='addvac'),
    path('vac_list',views.vaccinelist, name='list'),
    path('uservac_list',views.uservaccinelist, name='list'),
    path('user_list',views.userlist, name='userlist'),
    path('add_va',views.addvaccines, name='add_va'),
    path('adduser',views.adduser, name='adduser'),
    path('delete/<int:pk>',views.deletevaccines,name='delete'),
    path('deletehis/<int:pk>',views.deletehis,name='deletehis'),
    path('updatevac',views.updatehistory,name='updatevac'),
    path('updatevaccine',views.updatevaccine,name='updatevaccine')
]
