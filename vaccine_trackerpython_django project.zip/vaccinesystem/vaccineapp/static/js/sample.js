<script type="text/javascript">
                  function reg()
                  {
                  <form action="/action_page.php">
                    <h2>Register Form</h2>
                    <div class="input-container">
                      <i class="fa fa-user icon"></i>
                      <input class="input-field" type="text" placeholder="Username" name="usrnm">Username</input>
                    </div>
                  </form>
                  }
                  </script>